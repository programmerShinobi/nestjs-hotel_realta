INSERT INTO users.user_roles
    (usro_user_id,usro_role_id)
VALUES
    --Travel Agency
        --Corporate
            --Individual
    (1,1),
        (2,1),
            (3,1),

    (4,1),
        (5,1),
            (6,1),

    (7,1),
        (8,1),
            (9,1),

    (10,1),
        (11,1),
            (12,1),

    (13,2),
        (14,2),
            (15,2),

    (16,3),
        (17,3),
            (18,3),

    (19,4),
        (20,4),
            (21,4),

    (22,5),
        (23,5),
            (24,5)    