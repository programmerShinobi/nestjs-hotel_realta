INSERT INTO users.roles(role_id,role_name)
VALUES (1,'Guest'),(2,'Manager'),(3,'Office Boy'),(4,'Admin'),(5,'User');